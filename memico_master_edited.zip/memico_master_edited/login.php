<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Retrieve form data and handle login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email and password are non-empty
    if (empty($email) || empty($password)) {
        oci_close($conn);
        throw new Exception("Email and password cannot be empty");
    }

    // Establish a connection to the Oracle database
    $conn = oci_connect($db_username, $db_password, $host);

    if (!$conn) {
        $error = oci_error();
        die("Connection failed: " . $error['message']);
    }

    // Prepare the SQL statement
    $sql = "BEGIN
                SELECT password INTO :hashed_password FROM customer WHERE c_mail = :email;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20002, 'Invalid email');
            END;";
    $stmt = oci_parse($conn, $sql);

    // Bind the parameters
    oci_bind_by_name($stmt, ':email', $email);
    oci_bind_by_name($stmt, ':hashed_password', $hashed_password, 255);

    // Execute the statement
    $result = oci_execute($stmt);

    try {
        // Verify the hashed password
        if (isset($hashed_password) && !empty($hashed_password) && password_verify($password, $hashed_password)) {
            echo "Login successful!";
            setcookie('email', $email, time() + 3600, '/');
            header("Location: homepageprev.html");
            exit();
        } else {
            oci_close($conn);
            throw new Exception("Invalid email or password");
        }
    } catch (Exception $e) {
        echo $e->getMessage();
    }

    // Clean up
    oci_free_statement($stmt);
    oci_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      max-width: 500px;
      margin: 0 auto;
      padding: 40px;
      background-color: #f1f1f1;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    }

    .container h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #555;
    }

    .container label {
      font-weight: bold;
      display: block;
      margin-bottom: 10px;
    }

    .container input[type="text"],
    .container input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    .container .checkbox-container {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
    }

    .container .checkbox-container label {
      display: inline-block;
      margin-left: 10px;
    }

    .container input[type="submit"] {
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .container input[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
  <script>
    function togglePasswordVisibility() {
      var passwordInput = document.getElementById("password");
      var showPasswordCheckbox = document.getElementById("showPassword");
      
      if (showPasswordCheckbox.checked) {
        passwordInput.type = "text";
      } else {
        passwordInput.type = "password";
      }
    }
  </script>
</head>
<body>
  <div class="container">
    <h2>Login</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
      <label for="email">Email:</label>
      <input type="text" id="email" name="email" required>

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
      
      <div class="checkbox-container">
        <input type="checkbox" id="showPassword" onchange="togglePasswordVisibility()">
        <label for="showPassword">Show Password</label>
      </div>

      <input type="submit" value="Login">
    </form>
  </div>
</body>
</html>
