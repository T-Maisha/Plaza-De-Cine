<?php
// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Check if the rating form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rating'])) {
  // Get the input values from the form
  $movieName = $_POST['movie_name'];
  $rating = $_POST['rating'];

  // Validate the input values (you can add more validation if required)
  if (empty($movieName) || empty($rating)) {
    echo "Please fill in all the fields.";
    exit;
  }

  // Establish a connection to the Oracle database
  $conn = oci_connect($db_username, $db_password, $host);

  if (!$conn) {
    $error = oci_error();
    die("Connection failed: " . $error['message']);
  }

  // Perform necessary sanitization and validation of input values before inserting into the database
  $rating = round(floatval($rating), 2);

  // Retrieve the previous rating for the movie from the database
  $previousRating = 0; // Default value if no previous rating found

  // Convert both movie names to lowercase for case-insensitive comparison
  $movieNameLower = strtolower($movieName);

  $query = "SELECT rating FROM movies WHERE LOWER(MOVIE_NAME) = :movieNameLower";
  $stmt = oci_parse($conn, $query);
  oci_bind_by_name($stmt, ":movieNameLower", $movieNameLower);
  oci_execute($stmt);

  if ($row = oci_fetch_assoc($stmt)) {
    // Calculate the new average rating
    $previousRating = $row['RATING'];
    $newRating = round((($previousRating + $rating) / 2), 2);

    // Update the rating value in the database
    $updateQuery = "UPDATE movies SET rating = :newRating WHERE LOWER(MOVIE_NAME) = :movieNameLower";
    $updateStmt = oci_parse($conn, $updateQuery);
    oci_bind_by_name($updateStmt, ":newRating", $newRating);
    oci_bind_by_name($updateStmt, ":movieNameLower", $movieNameLower);
    oci_execute($updateStmt);

    // Display the previous and new ratings inside a container
    echo "<div class='rating-container'>";
    echo "<div class='rating-output'>";
    echo "<p>Movie name: " . $movieName . "</p>";
    echo "<p>Previous Rating: " . number_format($previousRating, 2) . "/10</p>";
    echo "<p>New Rating: " . number_format($newRating, 2) . "/10</p>";
    echo "</div>";
    echo "</div>";
  } else {
    echo "Movie not found.";
  }

  // Clean up
  oci_free_statement($stmt);
  oci_free_statement($updateStmt);
  oci_close($conn);
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Forum</title>
  <link rel="stylesheet" type="text/css" href="forum.css">
  <style>
    .rating-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .rating-output {
      text-align: center;
    }
  </style>
</head>

</html>
