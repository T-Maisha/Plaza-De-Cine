<?php
// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Initialize the visibility variables
$customerListVisible = false;
$managerListVisible = false;
$foodListVisible = false;
$minfoodList= false;

// Check if the "View Customer List" button is pressed
if (isset($_GET['viewCustomers'])) {
    // Toggle the visibility
    $customerListVisible = !$customerListVisible;
}

// Check if the "View Manager List" button is pressed
if (isset($_GET['viewManagers'])) {
    // Toggle the visibility
    $managerListVisible = !$managerListVisible;
}

// Check if the "View Food List from Database" button is pressed
if (isset($_GET['viewFoodList1'])) {
    // Toggle the visibility
    $foodListVisible = !$foodListVisible;
}
if (isset($_GET['minlist'])) { 
    // Toggle the visibility 
    $minfoodList = !$minfoodList; 
}

// Check if the "Delete" button is pressed
if (isset($_GET['delete'])) {
    // Get the customer ID and phone number from the query parameters
    $customerId = $_GET['c_id'];
    $phoneNumber = $_GET['phone'];

    // Establish a connection to the Oracle database
    $conn = oci_connect($db_username, $db_password, $host);

    if (!$conn) {
        $error = oci_error();
        die("Connection failed: " . $error['message']);
    }

    // Prepare the SQL statement to delete the phone number
    $stmt = oci_parse($conn, "DELETE FROM c_mobil_no WHERE c_id = :customerId AND phone = :phoneNumber");
    oci_bind_by_name($stmt, ':customerId', $customerId);
    oci_bind_by_name($stmt, ':phoneNumber', $phoneNumber);

    // Execute the delete statement
    $result = oci_execute($stmt);

    // Check if any rows were affected
    $rowsAffected = oci_num_rows($stmt);

    // Clean up
    oci_free_statement($stmt);

    if ($rowsAffected == 0) {
        // No more phone number for the customer, delete the customer as well
        $stmt = oci_parse($conn, "DELETE FROM customer WHERE c_id = :customerId");
        oci_bind_by_name($stmt, ':customerId', $customerId);
        oci_execute($stmt);

        // Clean up
        oci_free_statement($stmt);
    }

    oci_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="managerpage.css">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Styles for the back button */
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-family: Arial, sans-serif;
        }

        .back-button:hover {
            background-color: #555;
        }

        .back-button:active {
            background-color: #222;
        }
    </style>
</head>
<body>
<header>
    <h1>Manager Homepage</h1>
</header>

<div class="content">
    <div class="list-option">
        <form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <button type="submit" name="viewCustomers">View Customer List</button>
        </form>
    </div>

    <div class="list-option">
        <form method="GET" action="food.html">
            <button type="submit" name="viewFoodList">View Food List</button>
        </form>
    </div>

    <div class="list-option">
        <form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <button type="submit" name="viewManagers">View Manager List</button>
        </form>
    </div>

    <div class="list-option"> 
        <form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>"> 
            <button type="submit" name="minlist">Budget friendly Menu</button> 
        </form> 
    </div>
    
    <div class="list-option">
        <form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <button type="submit" name="viewFoodList1">View Food List from Database</button>
        </form>
    </div>

    <div>
        <!-- Back button -->
        <a href="homepage-1.html" class="back-button">Back</a>
    </div>

    <?php
    // Display the customer list if it's visible
    if ($customerListVisible) {
        // Establish a connection to the Oracle database
        $conn = oci_connect($db_username, $db_password, $host);

        if (!$conn) {
            $error = oci_error();
            die("Connection failed: " . $error['message']);
        }

        // Retrieve the customer information from the database
        $sql = "SELECT * FROM customer_list";
        $stmt = oci_parse($conn, $sql);
        oci_execute($stmt);

        // Display the customer information in a table
        echo "<table>";
        echo "<tr><th>Customer ID</th><th>Name</th><th>Phone</th><th>Email</th><th>District</th><th>Zip Code</th><th>Action</th></tr>";

        while ($row = oci_fetch_assoc($stmt)) {
            echo "<tr>";
            echo "<td>" . $row['C_ID'] . "</td>";
            echo "<td>" . $row['C_NAME'] . "</td>";
            echo "<td>" . $row['PHONE'] . "</td>";
            echo "<td>" . $row['C_MAIL'] . "</td>";
            echo "<td>" . $row['DISTRICT'] . "</td>";
            echo "<td>" . $row['ZIP_CODE'] . "</td>";
            echo '<td><form method="GET" action="' . $_SERVER['PHP_SELF'] . '"><input type="hidden" name="c_id" value="' . $row['C_ID'] . '"><input type="hidden" name="phone" value="' . $row['PHONE'] . '"><button type="submit" name="delete" style="background-color: red; color: white;">Delete</button></form></td>';
            echo "</tr>";
        }
        echo "</table>";

        // Clean up
        oci_free_statement($stmt);
        oci_close($conn);
    }

    // Display the manager list if it's visible
    if ($managerListVisible) {
        // Establish a connection to the Oracle database
        $conn = oci_connect($db_username, $db_password, $host);

        if (!$conn) {
            $error = oci_error();
            die("Connection failed: " . $error['message']);
        }

        // Retrieve the manager information from the database
        $sql = "SELECT * FROM manager";
        $stmt = oci_parse($conn, $sql);
        oci_execute($stmt);

        // Display the manager information in a table
        echo "<table>";
        echo "<tr><th>Manager ID</th><th>Name</th><th>House No</th><th>Zip Code</th><th>Street</th><th>District</th></tr>";

        while ($row = oci_fetch_assoc($stmt)) {
            echo "<tr>";
            echo "<td>" . $row['M_ID'] . "</td>";
            echo "<td>" . $row['M_NAME'] . "</td>";
            echo "<td>" . $row['HOUSE_NO'] . "</td>";
            echo "<td>" . $row['ZIP_CODE'] . "</td>";
            echo "<td>" . $row['STREET'] . "</td>";
            echo "<td>" . $row['DISTRICT'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";

        // Clean up
        oci_free_statement($stmt);
        oci_close($conn);
    }

    // Display the food list if it's visible
    if ($foodListVisible) {
        // Establish a connection to the Oracle database
        $conn = oci_connect($db_username, $db_password, $host);

        if (!$conn) {
            $error = oci_error();
            die("Connection failed: " . $error['message']);
        }

        // Retrieve the food information from the database
        $sql = "SELECT FO.STALL_NAME, H.PRICE, F.FOOD_NAME, F.FOOD_TYPE
        FROM food_stall FO
        JOIN have H ON FO.FS_ID = H.FS_ID
        JOIN food F ON H.FOOD_ID = F.FOOD_ID";
        $stmt = oci_parse($conn, $sql);
        oci_execute($stmt);

        // Display the food information in a table
        echo "<table>";
        echo "<tr><th>Stall Name</th><th>Price</th><th>Food Name</th><th>Food Type</th></tr>";

        while ($row = oci_fetch_assoc($stmt)) {
            echo "<tr>";
            echo "<td>" . $row['STALL_NAME'] . "</td>";
            echo "<td>" . $row['PRICE'] . "</td>";
            echo "<td>" . $row['FOOD_NAME'] . "</td>";
            echo "<td>" . $row['FOOD_TYPE'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";

        // Clean up
        oci_free_statement($stmt);
        oci_close($conn);
    }
    if ($minfoodList) { 
        // Establish a connection to the Oracle database 
        $conn = oci_connect($db_username, $db_password, $host); 
     
        if (!$conn) { 
            $error = oci_error(); 
            die("Connection failed: " . $error['message']); 
        } 
     
        // Retrieve the minimum food prices and food types from the database 
        $sql = "SELECT MIN(H.PRICE) AS MIN_PRICE, F.FOOD_TYPE 
                FROM have H 
                JOIN food F ON H.food_id = F.food_id 
                GROUP BY F.FOOD_TYPE"; 
        $stmt = oci_parse($conn, $sql); 
        oci_execute($stmt); 
     
        // Display the minimum food prices and food types in a table 
        echo "<table>"; 
        echo "<tr><th>Minimum Price</th><th>Food Type</th></tr>"; 
     
        while ($row = oci_fetch_assoc($stmt)) { 
            echo "<tr>"; 
            echo "<td>" . $row['MIN_PRICE'] . "</td>"; 
            echo "<td>" . $row['FOOD_TYPE'] . "</td>"; 
            echo "</tr>"; 
        } 
        echo "</table>"; 
     
        // Clean up 
        oci_free_statement($stmt); 
        oci_close($conn); 
     
}
    ?>
</div>
</body>
</html>
