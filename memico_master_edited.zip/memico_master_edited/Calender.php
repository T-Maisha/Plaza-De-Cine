<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="movie_info.css">
</head>
<body>
  <?php
  // Oracle database credentials
  $host = "localhost/XE";
  $db_username = "dbms";
  $db_password = "7";

  // Retrieve the date from the previous page
  if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['date'])) {
    $date = $_GET['date'];

    // Establish a connection to the Oracle database
    $conn = oci_connect($db_username, $db_password, $host);

    if (!$conn) {
      $error = oci_error();
      die("Connection failed: " . $error['message']);
    }
    $movieName = $_COOKIE['movie_name'];
    // Prepare the SQL statement
    $sql = "SELECT
              Movie_Name,
              Capacity,
              TO_CHAR(Show_Date, 'YYYY-MM-DD') AS Show_Date,
              TO_CHAR(Show_Date, 'HH24:MI:SS') AS Show_Time
            FROM
              hall_Room
              NATURAL JOIN show
              NATURAL JOIN movies
            WHERE
              TO_CHAR(Show_Date, 'MM/DD/YYYY') = '$date'
              and Movie_Name = '$movieName'";
    $stmt = oci_parse($conn, $sql);
    // Bind the parameter
    oci_bind_by_name($stmt, ':date', $date);
    oci_bind_by_name($stmt, ':movieName', $movieName);
   
    // Execute the statement
    $result = oci_execute($stmt);

    $flag = 0;
    while ($row = oci_fetch_assoc($stmt)) {
      // Movie data found, display it on the webpage
      echo '<div class="movie-card">';
      echo '<div class="movie-info">';
      echo '<h2 class="movie-title">' . $row['MOVIE_NAME'] . '</h2>';
      echo '<p class="movie-date">Date: ' . $row['SHOW_DATE'] . '</p>';
      echo '<p class="movie-time">Time: ' . $row['SHOW_TIME'] . '</p>';
      echo '<p class="available-seats">Total Seats: ' . $row['CAPACITY'] . '</p>';
      echo '</div>';
      echo '<div class="movie-poster">';
      echo '<img src="' . $row['IMG'] . '" alt="Movie Poster">';
      echo '</div>';
      
      // Add the button for redirection
      echo '<div class="book-button">';
      echo '<a href="booking.php?date=' . $date . '&time=' . $row['SHOW_TIME'] . '" class="btn btn-theme" onclick="setCookies(\'' . $date . '\', \'' . $row['SHOW_TIME'] . '\')">Book Now</a>';
      echo '</div>';
      
      echo '</div>';
      $flag = 1;
    }
    



    if (!oci_fetch_assoc($stmt) and $flag==0) {
        // No movie data found
        echo '<p>No movie found with on selected date.</p>';
      }

    // Clean up
    oci_free_statement($stmt);
    oci_close($conn);

    // Back button
    echo '<button onclick="goBack()" style="margin-top: 20px;">Go Back</button>';
  } else {
    // Invalid or missing date
    echo '<p>Invalid request.</p>';
  }
  ?>

  <script>
    function setCookies(date, showTime) {
      document.cookie = "date=" + date;
      document.cookie = "show_time=" + showTime;
    }

    function goBack() {
      window.history.back();
    }
  </script>
</body>
</html>
