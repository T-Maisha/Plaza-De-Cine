<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Function to retrieve existing user data
function getExistingUserData($conn, $email)
{
    $query = "SELECT * FROM customer_list WHERE c_mail  = :email";
    $stmt = oci_parse($conn, $query);
    oci_bind_by_name($stmt, ':email', $email);
    oci_execute($stmt);
    return oci_fetch_assoc($stmt);
}

// Function to update user data in the database
function updateUserData($conn, $name, $address, $zipcode, $mobileno, $removemobileno, $c_id)
{
    // Update customer table
    $query = "UPDATE customer SET c_name = :name, DISTRICT = :address, zip_code = :zipcode WHERE c_id = :c_id";
    $stmt = oci_parse($conn, $query);
    oci_bind_by_name($stmt, ':name', $name);
    oci_bind_by_name($stmt, ':address', $address);
    oci_bind_by_name($stmt, ':zipcode', $zipcode);
    oci_bind_by_name($stmt, ':c_id', $c_id);
    oci_execute($stmt);

    // Add new mobile number to C_mobil_no table
    if (!empty($mobileno)) {
        $query = "INSERT INTO C_mobil_no (C_ID, phone) VALUES (:c_id, :mobileno)";
        $stmt = oci_parse($conn, $query);
        oci_bind_by_name($stmt, ':c_id', $c_id);
        oci_bind_by_name($stmt, ':mobileno', $mobileno);
        oci_execute($stmt);
    }

    // Remove selected mobile number from C_mobil_no table
    if (!empty($removemobileno)) {
        $query = "DELETE FROM C_mobil_no WHERE C_ID = $c_id AND phone = '$removemobileno'";
        $stmt = oci_parse($conn, $query);
        oci_bind_by_name($stmt, ':c_id', $c_id);
        oci_bind_by_name($stmt, ':removemobileno', $removemobileno);
        oci_execute($stmt);
    }
}

// Establish a connection to the Oracle database
$conn = oci_connect($db_username, $db_password, $host);

if (!$conn) {
    $error = oci_error();
    die("Connection failed: " . $error['message']);
}

// Retrieve the email from the cookie
$email = $_COOKIE['email'];
// Retrieve existing user data
$userData = getExistingUserData($conn, $email); //fetch
$c_id = $userData['C_ID'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $zipcode = $_POST['zipcode'];
    $mobileno = $_POST['mobileno'];
    $removemobileno = $_POST['removemobileno'];

    // Update user data in the database
    updateUserData($conn, $name, $address, $zipcode, $mobileno, $removemobileno, $c_id);

    // Redirect back to previous page or any desired page
    header("Location: homepageprev.html");
    exit();
}

// Close the connection
oci_close($conn);
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <h1 class="heading"><b>Edit your Registration Form</b></h1>
</head>
<link rel="stylesheet" type="text/css" href="reg.css">

<body>
    <div class="container">
        <form action="update.php" method="post">
            <label for="name"><b>Edit Name:</b></label>
            <input type="text" id="name" name="name" placeholder="Enter your new Name...." value="<?php echo $userData['C_NAME']; ?>">

            <label for="address"><b>Edit District:</b></label>
            <input type="text" id="address" name="address" placeholder="Enter your new address...." value="<?php echo $userData['DISTRICT']; ?>">

            <label for="zipcode"><b>Edit Zip Code:</b></label>
            <input type="text" id="zipcode" name="zipcode" placeholder="Enter the zip code of your new area...." value="<?php echo $userData['ZIP_CODE']; ?>">

            <label for="mobileno"><b>Add Mobile No.:</b></label>
            <input type="text" id="mobileno" name="mobileno" placeholder="Enter the new mobile number....">

            <label for="removemobileno"><b>Remove Mobile No.:</b></label>
            <select id="removemobileno" name="removemobileno">
                <option value="">Select mobile number to remove</option>
                <?php
                // Establish a connection to the Oracle database
                $conn = oci_connect($db_username, $db_password, $host);

                if (!$conn) {
                    $error = oci_error();
                    die("Connection failed: " . $error['message']);
                }
                // Retrieve the existing mobile numbers for the user
                $query = "SELECT phone FROM C_mobil_no WHERE C_ID = :c_id";
                $stmt = oci_parse($conn, $query);
                oci_bind_by_name($stmt, ':c_id', $c_id);
                oci_execute($stmt);

                while ($row = oci_fetch_assoc($stmt)) {
                    $phoneNumber = $row['PHONE'];
                    echo "<option value=$phoneNumber>$phoneNumber</option>";
                }

                oci_free_statement($stmt);
                oci_close($conn);
                ?>
            </select>

            <div class="centered-button">
                <button type="submit">Submit</button>
                <button type="button" onclick="window.history.back();">Back</button>
            </div>
        </form>
    </div>

</body>

</html>