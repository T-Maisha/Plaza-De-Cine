<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="movie_info.css">
</head>
<body>
  <?php
  // Oracle database credentials
  $host = "localhost/XE";
  $db_username = "dbms";
  $db_password = "7";

  // Retrieve the movie name from the previous page
  if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['movie_name'])) {
    $movie_name = $_GET['movie_name'];

    // Establish a connection to the Oracle database
    $conn = oci_connect($db_username, $db_password, $host);

    if (!$conn) {
      $error = oci_error();
      die("Connection failed: " . $error['message']);
    }

    // Prepare the SQL statement
    $sql = "SELECT
    Movie_Name,
    Capacity,
    TO_CHAR(Show_Date, 'YYYY-MM-DD') AS Show_Date,
    TO_CHAR(Show_Date, 'HH24:MI:SS') AS Show_Time
  FROM
    hall_Room
    NATURAL JOIN show
    NATURAL JOIN movies
  WHERE
    LOWER(Movie_Name) LIKE '%' || LOWER(:movie_name) || '%'";

    $stmt = oci_parse($conn, $sql);

    // Bind the parameter
    oci_bind_by_name($stmt, ':movie_name', $movie_name);

    // Execute the statement
    $result = oci_execute($stmt);
    $flag=0;
    while ($row = oci_fetch_assoc($stmt)) {
      // Movie data found, display it on the webpage
      echo '<div class="movie-card">';
      echo '<div class="movie-info">';
      echo '<h2 class="movie-title">' . $row['MOVIE_NAME'] . '</h2>';
      echo '<p class="movie-date">Date: ' . $row['SHOW_DATE'] . '</p>';
      echo '<p class="movie-time">Time: ' . $row['SHOW_TIME'] . '</p>';
      //echo '<p class="hall-number">Hall: ' . $row['HALL_NUMBER'] . '</p>';
      echo '<p class="available-seats">Total Seats: ' . $row['CAPACITY'] . '</p>';
      echo '</div>';
      echo '<div class="movie-poster">';
      //echo '<img src="' . $row['POSTER_URL'] . '" alt="Movie Poster">';
      echo '</div>';
      echo '</div>';
      $flag=1;
    }

    if (!oci_fetch_assoc($stmt) and $flag==0) {
      // No movie data found
      echo '<p>No movie found with the given name.</p>';
    }

    // Clean up
    oci_free_statement($stmt);
    oci_close($conn);
    // Back button
    echo '<button onclick="goBack()" style="margin-top: 20px;">Go Back</button>';
  } else {
    // Invalid or missing movie name
    echo '<p>Invalid request.</p>';
  }
  ?>
   <script>
    function goBack() {
      window.history.back();
    }
  </script>
</body>
</html>
