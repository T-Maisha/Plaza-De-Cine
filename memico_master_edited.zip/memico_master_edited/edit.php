<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

$conn = oci_connect($db_username, $db_password, $host);
if (!$conn) {
    $error = oci_error();
    die("Connection failed: " . $error['message']);
}
// Retrieve form data
$username = $_COOKIE['username'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Establish a connection to the Oracle database


    // Prepare the SQL statement
    $sql = "SELECT * FROM users WHERE username = :username";
    $stmt = oci_parse($conn, $sql);

    // Bind the parameters
    oci_bind_by_name($stmt, ':username', $username);


    // Execute the statement
    $result = oci_execute($stmt);

    if ($row = oci_fetch_assoc($stmt)) {
        echo "Login successful! Welcome, " . $row['FULLNAME'];
        // You can redirect the user to a different page here
    } else {
        echo "Invalid username or password";
    }

    // Clean up
    oci_free_statement($stmt);
    oci_close($conn);
}
?>
