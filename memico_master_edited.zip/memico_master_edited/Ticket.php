<?php
// Replace with your own database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Establish a connection to the Oracle database
$conn = oci_connect($db_username, $db_password, $host);

if (!$conn) {
    $error = oci_error();
    die("Connection failed: " . $error['message']);
}

$ticketId = $_COOKIE['ticket_id'];

// Retrieve the ticket details from the database
$sql = "SELECT T_ID, C_name, MovieName, showtime, seat_id, total FROM Tickets where T_ID=:ticket_id";
$stmt = oci_parse($conn, $sql);
oci_bind_by_name($stmt, ':ticket_id', $ticketId);
oci_execute($stmt);

// Fetch the ticket details
if ($row = oci_fetch_assoc($stmt)) {
    $ticketId = $row['T_ID'];
    $customerName = $row['C_NAME'];
    $movieName = $row['MOVIENAME'];
    $showTime = $row['SHOWTIME'];
    $seatNo = $row['SEAT_ID'];
    $totalPrice = $row['TOTAL'];
} else {
    // No ticket found
    $ticketId = "N/A";
    $customerName = "N/A";
    $movieName = "N/A";
    $showTime = "N/A";
    $seatNo = "N/A";
    $totalPrice = "N/A";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Movie Ticket</title>
    <link rel="stylesheet" type="text/css" href="Ticket.css">
    <style>
        span {
            color: white;
        }
    </style>
</head>
<body>
    <div class="ticket">
        <h2>Movie Ticket</h2>
        <p><strong>Ticket ID:</strong> <span id="ticketId"><?php echo $ticketId; ?></span></p>
        <p><strong>Customer Name:</strong> <span id="customerName"><?php echo $customerName; ?></span></p>
        <p><strong>Movie Name:</strong> <span id="movieName"><?php echo $movieName; ?></span></p>
        <p><strong>Show Time:</strong> <span id="showtime"><?php echo $showTime; ?></span></p>
        <p><strong>Seat No:</strong> <span id="seatNo"><?php echo $seatNo; ?></span></p>
        <p><strong>Total Price:</strong> <span id="price"><?php echo $totalPrice; ?></span></p>
    </div>
</body>
</html>
