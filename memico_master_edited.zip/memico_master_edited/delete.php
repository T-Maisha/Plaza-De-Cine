<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";
$conn = oci_connect($db_username, $db_password, $host);
if (!$conn) {
    $error = oci_error();
    die("Connection failed: " . $error['message']);
}

// Retrieve form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $c_id = $_POST['C_ID'];

    // Prepare the SQL statement for deleting customer record
    $sql1 = "DELETE FROM C_MOBIL_NO WHERE C_ID = :c_id";
    $stmt1 = oci_parse($conn, $sql1);

    // Bind the parameter
    oci_bind_by_name($stmt1, ':c_id', $c_id);

    // Execute the statement
    $result1 = oci_execute($stmt1);

    // Prepare the SQL statement for deleting customer phone record
    $sql2 = "DELETE FROM CUSTOMER WHERE C_ID = :c_id";
    $stmt2 = oci_parse($conn, $sql2);

    // Bind the parameter
    oci_bind_by_name($stmt2, ':c_id', $c_id);

    // Execute the statement
    $result2 = oci_execute($stmt2);

    if ($result1 && $result2) {
        $rowsAffected1 = oci_num_rows($stmt1);
        $rowsAffected2 = oci_num_rows($stmt2);
        if ($rowsAffected1 > 0 || $rowsAffected2 > 0) {
            echo "Deletion successful!";
        } else {
            echo "No records found to delete.";
        }
        // Redirect to previous after 2 seconds
        exit;
    } else {
        $e1 = oci_error($stmt1);
        $e2 = oci_error($stmt2);
        echo "Error: " . $e1['message'] . "<br>";
        echo "Error: " . $e2['message'];
    }

    // Clean up
    oci_free_statement($stmt1);
    oci_free_statement($stmt2);
    oci_close($conn);
}
?>
