<?php
// Replace with your own database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Establish a connection to the Oracle database
$conn = oci_connect($db_username, $db_password, $host);

if (!$conn) {
    $error = oci_error();
    die("Connection failed: " . $error['message']);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the selected seat IDs
    if (isset($_POST['selected_seats']) && is_array($_POST['selected_seats'])) {
        $selectedSeats = $_POST['selected_seats'];

        // Generate a new ticket ID
        $sql = "SELECT ticket_seq.NEXTVAL FROM DUAL";
        $stmt = oci_parse($conn, $sql);
        oci_execute($stmt);
        $row = oci_fetch_assoc($stmt);
        $ticketID = $row['NEXTVAL'];

        // Get the movie name and show time from cookies
        $movieName = $_COOKIE['movie_name'];
        $showDate = $_COOKIE['date'];
        $showTime = $_COOKIE['show_time'];

        // Combine show_date and show_time into a single timestamp value
        $showDateTime = $showDate . ' ' . $showTime;
        // Insert each selected seat into the database
        $sql = "INSERT INTO seat_c  VALUES (:ticketID, :seatID, :movieName, TO_TIMESTAMP(:showDateTime, 'MM/DD/YYYY HH24:MI:SS'))";
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ":ticketID", $ticketID);
        oci_bind_by_name($stmt, ":seatID", $seatID);
        oci_bind_by_name($stmt, ":movieName", $movieName);
        oci_bind_by_name($stmt, ":showDateTime", $showDateTime);

        foreach ($selectedSeats as $seatID) {
            // Extract the row letter and column number
            $rowLetter = substr($seatID, 0, 1);
            $columnNumber = substr($seatID, 1);

            // Create the seat ID with the column number padded with leading zeros
            $formattedSeatID = $rowLetter . str_pad($columnNumber, 2, '0', STR_PAD_LEFT);

            // Bind the formatted seat ID to the statement
            oci_bind_by_name($stmt, ":seatID", $formattedSeatID);

            oci_execute($stmt);
        }
        // Get the customer name from the database based on the email cookie
        $email = $_COOKIE['email'];
        $sql = "SELECT C_NAME FROM CUSTOMER WHERE C_MAIL = :email";
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ":email", $email);
        oci_execute($stmt);
        $row = oci_fetch_assoc($stmt);
        $customerName = $row['C_NAME'];
        if($customerName == null) $customerName = "Guest";


        // Calculate the total price
        $totalSeats = count($selectedSeats);
        $totalPrice = $totalSeats * 350;
        $seatIDs = implode(",", $selectedSeats);
        // Insert the ticket details into the database
        $sql = "INSERT INTO Tickets (T_ID, C_name, MovieName, showtime, seat_id, total) 
                VALUES (:ticketID, :customerName, :movieName, TO_TIMESTAMP(:showDateTime, 'MM/DD/YYYY HH24:MI:SS'), :seatIDs, :totalPrice)";
        $stmt = oci_parse($conn, $sql);
        oci_bind_by_name($stmt, ":ticketID", $ticketID);
        oci_bind_by_name($stmt, ":customerName", $customerName);
        oci_bind_by_name($stmt, ":movieName", $movieName);
        oci_bind_by_name($stmt, ":showDateTime", $showDateTime);
        oci_bind_by_name($stmt, ":seatIDs", $seatIDs);
        oci_bind_by_name($stmt, ":totalPrice", $totalPrice);
        oci_execute($stmt);

        setcookie("ticket_id", $ticketID, time() + (3600), "/"); 

        // Redirect to ticket.html
        header("Location: Ticket.php");
        exit();
    }
}
?>



<!DOCTYPE html>
<html>

<head>
    <title>Seat Booking</title>
    <style>
        .hall-layout {
            display: flex;
            justify-content: center;
            max-width: 600px;
            margin: 0 auto;
            padding-top: 20px;
            flex-wrap: wrap;
        }

        .row {
            display: flex;
            justify-content: center;
            margin-bottom: 10px;
        }

        .seat {
            flex: 0 0 50px;
            height: 50px;
            margin: 5px;
            border: 1px solid #ccc;
            text-align: center;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            background-color: #020702;
            /* Default seat color */
            color: #fff;
            /* Default seat text color */
        }

        .seat.available {
            background-color: #020702;
            /* Available seat color */
        }

        .seat.booked {
            background-color: #dc3545;
            /* Booked seat color */
            cursor: not-allowed;
        }

        .seat.selected {
            background-color: #28a745;
            /* Selected seat color */
        }

        .btn {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center my-4">Select Seats</h2>

        <form action="booking.php" method="POST">
            <?php
            // Retrieve the booked seats for the current movie and showtime
            $movieName = $_COOKIE['movie_name'];
            $showDate = $_COOKIE['date'];
            $showTime = $_COOKIE['show_time'];
            $showDateTime = $showDate . ' ' . $showTime;

            $sql = "SELECT seat_id FROM seat_c WHERE MovieName = :movieName AND showtime = TO_TIMESTAMP(:showDateTime, 'MM/DD/YYYY HH24:MI:SS')";
            $stmt = oci_parse($conn, $sql);
            oci_bind_by_name($stmt, ":movieName", $movieName);
            oci_bind_by_name($stmt, ":showDateTime", $showDateTime);
            oci_execute($stmt);
            $bookedSeats = array();
            while ($row = oci_fetch_assoc($stmt)) {
                $bookedSeats[] = $row['SEAT_ID'];
            }

            // Generate the seat layout
            echo '<div class="hall-layout">';

            // Rows A to J
            for ($row = 1; $row <= 10; $row++) {
                echo '<div class="row">';

                // Seats 01 to 5
                for ($seat = 1; $seat <= 5; $seat++) {
                    $seatNumber = chr($row + 64) . sprintf("%02d", $seat);
                    $seatClass = in_array($seatNumber, $bookedSeats) ? 'booked' : 'available';
                    echo '<div class="seat ' . $seatClass . '">';
                    echo '<input type="checkbox" name="selected_seats[]" value="' . $seatNumber . '" ' . ($seatClass === 'booked' ? 'disabled' : '') . ($seatClass === 'booked' ? ' checked' : '') . '>';
                    echo $seatNumber;
                    echo '</div>';
                }

                // Gap inside the rows
                echo '<div style="flex: 0 0 60px;"></div>';

                // Seats 06 to 10
                for ($seat = 6; $seat <= 10; $seat++) {
                    $seatNumber = chr($row + 64) . sprintf("%02d", $seat);
                    $seatClass = in_array($seatNumber, $bookedSeats) ? 'booked' : 'available';
                    echo '<div class="seat ' . $seatClass . '">';
                    echo '<input type="checkbox" name="selected_seats[]" value="' . $seatNumber . '" ' . ($seatClass === 'booked' ? 'disabled' : '') . ($seatClass === 'booked' ? ' checked' : '') . '>';
                    echo $seatNumber;
                    echo '</div>';

                    // Update seat_c class for booked seats
                    if ($seatClass === 'booked') {
                        echo "<style>.seat_c." . $seatNumber . "{ background-color: #dc3545; cursor: not-allowed; }</style>";
                    }
                }
                echo '</div>';
            }

            echo '</div>';
            ?>

            <button type="submit" class="btn btn-outline-danger mt-3">Book</button>
        </form>
    </div>

    <script>
        // Add event listener to checkboxes
        const checkboxes = document.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const seat = this.parentElement;
                seat.classList.toggle('selected');
            });
        });
    </script>

</body>

</html>