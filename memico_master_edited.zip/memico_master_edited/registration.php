<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Function to validate email format
function validateEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function to validate mobile number length
function validateMobileNumber($phone)
{
    $phoneNumbers = explode(',', $phone);
    foreach ($phoneNumbers as $number) {
        $number = preg_replace('/\D/', '', $number);
        if (strlen($number) != 11 || !preg_match("/^01/", $number)) {
            return false;
        }
    } 
    return true;
}

// Define variables for error messages
$nameErr = $phoneErr = $emailErr = $passwordErr = $districtErr = $zipcodeErr = "";

// Retrieve form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $district = $_POST['district'];
    $zipcode = $_POST['zipcode'];

    // Check if any field is empty or mobile/email format is invalid
    if (empty($name)) {
        $nameErr = "Name is required";
    }
    if (empty($phone)) {
        $phoneErr = "Phone number is required";
    } elseif (!validateMobileNumber($phone)) {
        $phoneErr = "Invalid phone number format";
    }
    if (empty($email)) {
        $emailErr = "Email is required";
    } elseif (!validateEmail($email)) {
        $emailErr = "Invalid email format";
    }
    if (empty($password)) {
        $passwordErr = "Password is required";
    }
    if (empty($district)) {
        $districtErr = "District is required";
    }
    if (empty($zipcode)) {
        $zipcodeErr = "Zipcode is required";
    } elseif (strlen($zipcode) !== 4) {
        $zipcodeErr = "Zipcode must be 4 digits";
    }

    // If there are no errors, proceed with database insertion
    if (empty($nameErr) && empty($phoneErr) && empty($emailErr) && empty($passwordErr) && empty($districtErr) && empty($zipcodeErr)) {
        // Hash the password
        $options = [
            'cost' => 12, // adjust the cost according to your server performance
        ];

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT, $options);

        // Establish a connection to the Oracle database
        $conn = oci_connect($db_username, $db_password, $host);

        if (!$conn) {
            $error = oci_error();
            die("Connection failed: " . $error['message']);
        }

        // Prepare the SQL statement for inserting into the Customer table
        $sql = "INSERT INTO Customer (C_Name, C_Mail, District, Zip_Code, Password) VALUES (:name, :email, :district, :zipcode, :hashedPassword)";
        $stmt = oci_parse($conn, $sql);

        // Bind the parameters
        oci_bind_by_name($stmt, ':name', $name);
        oci_bind_by_name($stmt, ':email', $email);
        oci_bind_by_name($stmt, ':district', $district);
        oci_bind_by_name($stmt, ':zipcode', $zipcode);
        oci_bind_by_name($stmt, ':hashedPassword', $hashedPassword);

        // Execute the statement
        $result = oci_execute($stmt, OCI_COMMIT_ON_SUCCESS);

        if ($result) {
            // Retrieve the automatically generated C_ID
            $query = "SELECT customer_seq.CURRVAL FROM DUAL";
            $idStmt = oci_parse($conn, $query);
            oci_execute($idStmt);
            oci_fetch($idStmt);
            $c_id = oci_result($idStmt, 'CURRVAL');

            // Split phone numbers by comma
            $phoneNumbers = explode(',', $phone);

            // Prepare the SQL statement for inserting into the C_mobil_no table
            $phoneSql = "INSERT INTO C_mobil_no (C_ID, phone) VALUES (:c_id, :phone)";
            $phoneStmt = oci_parse($conn, $phoneSql);

            // Bind the C_ID parameter (common for all phone numbers)
            oci_bind_by_name($phoneStmt, ':c_id', $c_id);

            // Bind the phone parameter
            oci_bind_by_name($phoneStmt, ':phone', $phoneVal);

            // Execute the statement for each phone number
            foreach ($phoneNumbers as $phoneVal) {
                // Re-bind the phone parameter for each iteration
                oci_bind_by_name($phoneStmt, ':phone', $phoneVal);

                $phoneResult = oci_execute($phoneStmt, OCI_COMMIT_ON_SUCCESS);
                if (!$phoneResult) {
                    $error = oci_error($phoneStmt);
                    if ($error['code'] == 1 && strpos($error['message'], 'DBMS.SYS_C007493') !== false) {
                        // Unique constraint violation error
                        echo "This email already has an account.";
                    } else {
                        echo "Error: " . $error['message'];
                    }
                    oci_rollback($conn);
                    oci_close($conn);
                    exit;
                }
            }
            echo "Congratulations! Registration successful!";
            setcookie('email', $email, time() + 3600, '/');
            header("Location: homepageprev.html");
            exit();
        } else {
            $error = oci_error($stmt);
            if ($error['code'] == 1 && strpos($error['message'], 'DBMS.SYS_C007493') !== false) {
                // Unique constraint violation error
                echo "This email already has an account.";
            } else {
                echo "Error: " . $error['message'];
            }
        }

        // Clean up
        oci_free_statement($idStmt);
        oci_free_statement($phoneStmt);
        oci_free_statement($stmt);
        oci_close($conn);
    }
}

?>




<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <h1 class="heading"><b><b>Customer Registration Form</b></b></h1>
</head>

<body>
    <div class="container">
        <!-- <h1 class="heading">Customer Registration Form</h1> -->
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" value="<?php echo isset($name) ? $name : ''; ?>">
                <span class="error"><?php echo $nameErr; ?></span>
            </div>

            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" name="phone" id="phone" value="<?php echo isset($phone) ? $phone : ''; ?>">
                <span class="error"><?php echo $phoneErr; ?></span>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" name="email" id="email" value="<?php echo isset($email) ? $email : ''; ?>">
                <span class="error"><?php echo $emailErr; ?></span>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password">
                <span class="error"><?php echo $passwordErr; ?></span>
            </div>

            <div class="form-group">
                <label for="district">district:</label>
                <input type="text" name="district" id="district" value="<?php echo isset($district) ? $district : ''; ?>">
                <span class="error"><?php echo $districtErr; ?></span>
            </div>

            <div class="form-group">
                <label for="zipcode">Zipcode:</label>
                <input type="text" name="zipcode" id="zipcode" value="<?php echo isset($zipcode) ? $zipcode : ''; ?>">
                <span class="error"><?php echo $zipcodeErr; ?></span>
            </div>

            <div class="centered-button">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</body>

</html>