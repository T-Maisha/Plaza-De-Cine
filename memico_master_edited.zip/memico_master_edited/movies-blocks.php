<?php
// Oracle database credentials
$host = "localhost/XE";
$db_username = "dbms";
$db_password = "7";

// Establish a connection to the Oracle database
$conn = oci_connect($db_username, $db_password, $host);

if (!$conn) {
    $error = oci_error();
    die("Connection failed: " . $error['message']);
}

// Query to fetch the movie with the highest rating
$query = "SELECT movie_name, rating FROM movies WHERE rating = (SELECT MAX(rating) FROM movies)";
$stmt = oci_parse($conn, $query);
oci_execute($stmt);

// Fetch the movie details
if ($row = oci_fetch_assoc($stmt)) {
    $mostPopularMovie = $row['MOVIE_NAME'];
    $highestRating = $row['RATING'];
} else {
    $mostPopularMovie = "";
    $highestRating = "";
}

// Clean up
oci_free_statement($stmt);
oci_close($conn);
?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Plaza De Cine</title>
    <!-- Bootstrap -->
    <link href="./bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Animate.css -->
    <link href="./animate.css/animate.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome iconic font -->
    <link href="./fontawesome/css/fontawesome-all.css" rel="stylesheet" type="text/css" />
    <!-- Magnific Popup -->
    <link href="./magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />
    <!-- Slick carousel -->
    <link href="./slick/slick.css" rel="stylesheet" type="text/css" />
    <!-- Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Oswald:300,400,500,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
    <!-- Theme styles -->
    <link href="./css/dot-icons.css" rel="stylesheet" type="text/css">
    <link href="./css/theme.css" rel="stylesheet" type="text/css">
</head>

<body>
    <section class="section-long">
        <div class="container">
            <div class="section-head">
                <h2 class="section-title text-uppercase">MOVIE DETAILS</h2>
            </div>

            <div class="text-center mb-4">
                <h3 class="text-uppercase">Most Rated Movie</h3>
                <p><?php echo $mostPopularMovie; ?></p>
                <p>Rating: <?php echo $highestRating; ?></p>
            </div>

            <?php
            // Replace with your own database credentials
            $host = "localhost/XE";
            $db_username = "dbms";
            $db_password = "7";

            // Establish a connection to the Oracle database
            $conn = oci_connect($db_username, $db_password, $host);

            if (!$conn) {
                $error = oci_error();
                die("Connection failed: " . $error['message']);
            }

            // Prepare and execute the query to fetch movie details
            $query = 'SELECT * FROM movies';
            $statement = oci_parse($conn, $query);
            oci_execute($statement);

            // Fetch and display movie details
            while ($row = oci_fetch_assoc($statement)) {
                $movieName = $row['MOVIE_NAME'];
                $genre = $row['GENRE'];
                $rating = $row['RATING'];
                $duration = $row['DURATION'];
                $stars = $row['STAR_NAME'];
                $description = $row['MOVIE_DESC'];
                $posterUrl = $row['IMG'];


                echo '
                <article class="movie-line-entity">
                <div class="entity-poster" data-role="hover-wrap">
                <!-- Movie Poster -->
                <img class="embed-responsive-item" src="' . $posterUrl . '" alt="movie poster" style="max-width: 175px; height: auto;" />
                <div class="d-over bg-theme-lighted collapse animated faster" data-show-class="fadeIn show" data-hide-class="fadeOut show">
                    <div class="entity-play">
                        <!-- Movie Trailer -->
                        <a class="action-icon-theme action-icon-bordered rounded-circle" href="path_to_movie_trailer" data-magnific-popup="iframe">
                            <span class="icon-content"><i class="fas fa-play"></i></span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="entity-content">
                <h4 class="entity-title">
                    <a href="#">' . $movieName . '</a>
                </h4>
                <div class="entity-category">' . $genre . '</div>
                <div class="entity-info">
                    <div class="info-lines">
                        <div class="info">
                            <span class="text-theme">Rating:</span>
                            <span class="info-rest">' . $rating . '<span> out of 10</span></span>
                        </div>
                    </div>
                    <div class="info-lines">
                        <div class="info">
                            <span class="text-theme">Duration:</span>
                            <span class="info-rest">' . $duration . '</span>
                        </div>
                    </div>
                    <div class="info-lines">
                        <div class="info info-short">
                            <span class="text-theme">Stars:</span>
                            <span class="info-rest">' . $stars . '</span>
                        </div>
                    </div>
                </div>
                <div class="entity-content-footer">
                    <p>' . $description . '</p>
                    <form action="Calender.html" method="POST">
                        <input type="hidden" name="movie_name" value="' . $movieName . '">
                        <button type="submit" class="btn btn-primary" onclick="setCookie(\'movie_name\', \'' . $movieName . '\', 1)">Book Now</button>
                    </form>
                </div>
            </div>
        </article>
        ';
            }

            // Close the database connection
            oci_free_statement($statement);
            oci_close($conn);
            ?>

            <script>
                // JavaScript function to set a cookie
                function setCookie(cookieName, cookieValue, expiryDays) {
                    var d = new Date();
                    d.setTime(d.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
                    var expires = "expires=" + d.toUTCString();
                    document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
                }
            </script>
        </div>
    </section>
    <!-- JavaScript -->
    <script src="./jquery/jquery.min.js"></script>
    <script src="./popper/popper.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <script src="./magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="./slick/slick.min.js"></script>
    <script src="./scrollreveal/scrollreveal.min.js"></script>
    <script src="./jquery-easing/jquery.easing.min.js"></script>
    <script src="./js/theme.js"></script>
</body>

</html>